"""Small graph structures for concise algorithm examples and graph views."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field, replace

__all__ = ["Edge", "Graph", "NodeId", "Tree"]

type NodeId = str
type EdgeLabel = str | int | float
type Neighbors = list[NodeId] | dict[NodeId, EdgeLabel]


@dataclass(frozen=True, slots=True)
class Edge:
    """A labelled connection between two graph nodes."""

    source: NodeId
    target: NodeId
    label: str = ""


@dataclass(frozen=True)
class Graph:
    """An adjacency-list graph that can also be rendered directly."""

    adjacency: dict[NodeId, Neighbors]
    labels: dict[NodeId, object] = field(default_factory=dict)
    directed: bool = False
    current: NodeId | None = None

    def __getitem__(self, node: NodeId) -> Neighbors:
        return self.adjacency[node]

    def edges_from(self, node: NodeId) -> list[Edge]:
        """Return outgoing edges, preserving optional adjacency-map weights."""

        neighbors = self.adjacency[node]
        if isinstance(neighbors, Mapping):
            return [
                Edge(node, target, str(label)) for target, label in neighbors.items()
            ]
        return [Edge(node, target) for target in neighbors]

    def highlight(self, node: NodeId | None) -> Graph:
        """Return this graph with the node currently expanded by an algorithm."""

        return replace(self, current=node)


@dataclass(frozen=True)
class Tree:
    """A growing tree with generated node identifiers for search traces."""

    root_label: object
    root_id: NodeId = "t0"
    nodes: dict[NodeId, object] = field(default_factory=dict, repr=False)
    annotations: dict[NodeId, str] = field(default_factory=dict, repr=False)
    edges: tuple[Edge, ...] = ()
    current: NodeId | None = None
    _next_id: int = field(default=1, repr=False)

    def __post_init__(self) -> None:
        if not self.nodes:
            object.__setattr__(self, "nodes", {self.root_id: self.root_label})

    def add(
        self,
        parent: NodeId,
        label: object,
        edge_label: str = "",
        *,
        annotation: str = "",
    ) -> tuple[Tree, NodeId]:
        """Return a new tree with one child and that child's identifier."""

        child = f"t{self._next_id}"
        nodes = {**self.nodes, child: label}
        annotations = self.annotations
        if annotation:
            annotations = {**annotations, child: annotation}
        tree = replace(
            self,
            nodes=nodes,
            annotations=annotations,
            edges=(*self.edges, Edge(parent, child, edge_label)),
            _next_id=self._next_id + 1,
        )
        return tree, child

    def with_label(self, node: NodeId, label: object) -> Tree:
        """Return this tree with a node label updated."""

        if node not in self.nodes:
            raise KeyError(f"Unknown tree node: {node}")
        return replace(self, nodes={**self.nodes, node: label})

    def with_annotation(self, node: NodeId, annotation: str) -> Tree:
        """Return this tree with auxiliary text displayed outside a node."""

        if node not in self.nodes:
            raise KeyError(f"Unknown tree node: {node}")
        annotations = {**self.annotations}
        if annotation:
            annotations[node] = annotation
        else:
            annotations.pop(node, None)
        return replace(self, annotations=annotations)

    def highlight(self, node: NodeId | None) -> Tree:
        """Return this tree with the node currently expanded by an algorithm."""

        return replace(self, current=node)
