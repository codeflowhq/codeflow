"""Explicit atomic playback steps for traced examples."""

from __future__ import annotations

import ast
from collections.abc import Sequence
from contextlib import AbstractContextManager
from dataclasses import dataclass

from .types import VariableTraceEvent


class _AtomicStep(AbstractContextManager[None]):
    def __enter__(self) -> None:
        return None

    def __exit__(self, *_: object) -> bool:
        return False


def step() -> _AtomicStep:
    """Group the assignments in a ``with step():`` block into one playback frame."""

    return _AtomicStep()


@dataclass(frozen=True, slots=True)
class AtomicStepRange:
    header_line: int
    start_line: int
    end_line: int

    def contains(self, line_number: int) -> bool:
        return self.start_line <= line_number <= self.end_line


def atomic_step_ranges(source_code: str) -> list[AtomicStepRange]:
    """Find the body lines of explicit ``with step():`` blocks."""

    try:
        tree = ast.parse(source_code)
    except SyntaxError:
        return []

    ranges: list[AtomicStepRange] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.With) or not node.items or not node.body:
            continue
        context = node.items[0].context_expr
        if not (
            isinstance(context, ast.Call)
            and isinstance(context.func, ast.Name)
            and context.func.id == "step"
            and not context.args
            and not context.keywords
        ):
            continue
        ranges.append(
            AtomicStepRange(
                header_line=node.lineno,
                start_line=node.body[0].lineno,
                end_line=max(child.end_lineno or child.lineno for child in node.body),
            )
        )
    return ranges


def merge_atomic_step_events(
    events: Sequence[VariableTraceEvent],
    ranges: Sequence[AtomicStepRange],
) -> list[VariableTraceEvent]:
    """Give each execution of an explicit step block one trace identity."""

    if not ranges:
        return list(events)

    merged: list[VariableTraceEvent] = []
    active_range: AtomicStepRange | None = None
    transaction_execution_id: int | None = None
    previous_line: int | None = None

    for event in events:
        current_range = next(
            (item for item in ranges if item.contains(event.line_number)), None
        )
        if current_range is None:
            active_range = None
            transaction_execution_id = None
            previous_line = None
            merged.append(event)
            continue

        # A loop re-enters the block at its first line. That starts a new
        # atomic frame even if no watched event occurred between iterations.
        if (
            current_range != active_range
            or previous_line is None
            or event.line_number < previous_line
        ):
            active_range = current_range
            transaction_execution_id = event.execution_id
        previous_line = event.line_number
        merged.append(
            VariableTraceEvent(
                variable=event.variable,
                value=event.value,
                line_number=current_range.header_line,
                scope_id=event.scope_id,
                execution_id=transaction_execution_id or event.execution_id,
                var_id=event.var_id,
                access_path=event.access_path,
                order=event.order,
                access_paths=event.access_paths,
            )
        )
    return merged
