"""User-facing builder for the ``plot`` visualization view."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any, Literal, Self

SeriesKind = Literal["line", "scatter"]


class Plot(dict[str, Any]):
    """Build a plot payload without exposing renderer-specific dictionaries."""

    def __init__(
        self,
        *,
        x_domain: Sequence[float] | None = None,
        y_domain: Sequence[float] | None = None,
        x_label: str | None = None,
        y_label: str | None = None,
    ) -> None:
        super().__init__(series=[])
        if x_domain is not None:
            self["x_domain"] = list(x_domain)
        if y_domain is not None:
            self["y_domain"] = list(y_domain)
        if x_label is not None:
            self["x_label"] = x_label
        if y_label is not None:
            self["y_label"] = y_label

    @property
    def x_domain(self) -> Sequence[float] | None:
        return self.get("x_domain")

    @x_domain.setter
    def x_domain(self, value: Sequence[float]) -> None:
        self["x_domain"] = list(value)

    @property
    def y_domain(self) -> Sequence[float] | None:
        return self.get("y_domain")

    @y_domain.setter
    def y_domain(self, value: Sequence[float]) -> None:
        self["y_domain"] = list(value)

    @property
    def x_label(self) -> str | None:
        return self.get("x_label")

    @x_label.setter
    def x_label(self, value: str) -> None:
        self["x_label"] = value

    @property
    def y_label(self) -> str | None:
        return self.get("y_label")

    @y_label.setter
    def y_label(self, value: str) -> None:
        self["y_label"] = value

    def line(self, points: Sequence[Sequence[float]], *, color: str | None = None) -> Self:
        return self._add_series("line", points, color)

    def scatter(self, points: Sequence[Sequence[float]], *, color: str | None = None) -> Self:
        return self._add_series("scatter", points, color)

    def _add_series(
        self, kind: SeriesKind, points: Sequence[Sequence[float]], color: str | None
    ) -> Self:
        series: dict[str, Any] = {"kind": kind, "points": [list(point) for point in points]}
        if color is not None:
            series["color"] = color
        self["series"].append(series)
        return self
