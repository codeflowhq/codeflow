from __future__ import annotations

from collections import defaultdict
from collections.abc import Callable, Iterable, Mapping, Sequence
from itertools import groupby
from typing import Any

from ..pipeline.pipeline import visualize
from ..renderers.svg.chart_renderer import render_chart_svg
from ..shared.config import VisualizerConfig, default_visualizer_config
from ..shared.models import Artifact, ArtifactKind, Frame, Trace
from ..shared.view_kinds import ViewKind
from ..utils.value_shapes import is_numeric_point_sequence
from .types import RenderedTraceFrame, VariableTraceEvent


def build_traces(
    events: Sequence[VariableTraceEvent],
    *,
    name_factory: Callable[[str], str] | None = None,
) -> dict[str, Trace]:
    """Group trace events by variable name and convert them to Trace objects."""

    grouped: dict[str, list[Frame]] = defaultdict(list)
    for event in events:
        grouped[event.variable].append(
            Frame(
                step=event.execution_id,
                value=event.value,
                note=event.note(),
                meta={
                    "var_id": event.var_id,
                    "access_path": event.access_path,
                    "access_paths": list(event.access_paths or (event.access_path,)),
                    "scope_id": event.scope_id,
                    "line_number": event.line_number,
                    "execution_id": event.execution_id,
                    "order": event.order,
                },
            )
        )

    traces: dict[str, Trace] = {}
    for variable, frames in grouped.items():
        trace_name = name_factory(variable) if name_factory else variable
        traces[variable] = Trace(name=trace_name, frames=frames)
    return traces


def _focus_path_from_frame_meta(meta: Mapping[str, Any]) -> str | None:
    access_paths = [
        path for path in meta.get("access_paths", []) if isinstance(path, str)
    ]
    if access_paths:
        return max(access_paths, key=len)
    access_path = meta.get("access_path")
    return access_path if isinstance(access_path, str) else None


def visualize_trace(
    trace: Trace,
    *,
    config: VisualizerConfig | None = None,
    max_steps: int | None = None,
) -> list[Artifact]:
    """Render each trace step via the main visualize() helper."""

    cfg = (
        config.copy().normalized()
        if config is not None
        else default_visualizer_config().normalized()
    )
    artifacts: list[Artifact] = []
    limit = cfg.step_limit_for(trace.name, override=max_steps)
    selected_steps = trace.frames if limit is None else trace.frames[:limit]
    for frame in selected_steps:
        focus_path = _focus_path_from_frame_meta(frame.meta)
        if focus_path:
            cfg.focus_path_map[trace.name] = focus_path
        else:
            cfg.focus_path_map.pop(trace.name, None)
        # The rendered name contributes to Graphviz node IDs. Keep it stable
        # across timeline frames so d3-graphviz can match existing elements.
        artifacts.append(visualize(frame.value, name=trace.name, config=cfg))
    return artifacts


def visualize_traces(
    traces: Iterable[Trace],
    *,
    config: VisualizerConfig | None = None,
    max_steps: int | None = None,
) -> dict[str, list[RenderedTraceFrame]]:
    """Render multiple traces at once while preserving each frame's global step."""

    cfg = (
        config.copy().normalized()
        if config is not None
        else default_visualizer_config().normalized()
    )
    rendered: dict[str, list[RenderedTraceFrame]] = {}
    trace_list = list(traces)
    traces_by_name = {trace.name: trace for trace in trace_list}
    groups_by_owner = {group.owner: group for group in cfg.view_overlay_groups}
    for trace in trace_list:
        limit = cfg.step_limit_for(trace.name, override=max_steps)
        selected_steps = trace.frames if limit is None else trace.frames[:limit]
        group = groups_by_owner.get(trace.name)
        if group is not None:
            members = [traces_by_name[name] for name in group.layer_order if name in traces_by_name]
            if len(members) >= 2:
                rendered[trace.name] = _visualize_overlay_group(trace.name, members, cfg, max_steps)
                continue
        artifacts = visualize_trace(trace, config=cfg, max_steps=max_steps)
        rendered[trace.name] = [
            RenderedTraceFrame(step=frame.step, artifact=artifact, meta=dict(frame.meta))
            for frame, artifact in zip(selected_steps, artifacts, strict=False)
        ]
    return rendered


def _visualize_overlay_group(
    owner: str,
    traces: Sequence[Trace],
    config: VisualizerConfig,
    max_steps: int | None,
) -> list[RenderedTraceFrame]:
    """Render ordered line/scatter traces in one shared coordinate system."""

    kinds = {trace.name: config.view_name_map.get(trace.name) for trace in traces}
    if any(kind not in {ViewKind.LINE, ViewKind.SCATTER} for kind in kinds.values()):
        return []
    selected = {
        trace.name: trace.frames if max_steps is None else trace.frames[:max_steps]
        for trace in traces
    }
    events = sorted(
        (frame for frames in selected.values() for frame in frames),
        key=lambda frame: (int(frame.meta.get("order", frame.step)), frame.step),
    )
    domains = _overlay_domains([frame for frames in selected.values() for frame in frames])
    latest: dict[str, Frame] = {}
    rendered: list[RenderedTraceFrame] = []
    event_batches = groupby(
        events,
        key=lambda frame: int(frame.meta.get("execution_id", frame.step)),
    )
    for _, batch in event_batches:
        batch_frames = list(batch)
        event = batch_frames[-1]
        event_order = max(
            int(frame.meta.get("order", frame.step)) for frame in batch_frames
        )
        for trace in traces:
            current = next(
                (
                    frame
                    for frame in reversed(selected[trace.name])
                    if int(frame.meta.get("order", frame.step)) <= event_order
                ),
                None,
            )
            if current is not None:
                latest[trace.name] = current
        if len(latest) != len(traces) or any(
            not is_numeric_point_sequence(latest[trace.name].value) for trace in traces
        ):
            continue
        series: list[dict[str, Any]] = []
        for trace in traces:
            kind = kinds[trace.name]
            if kind is None:  # Guarded above; keeps the payload explicitly typed.
                continue
            series.append(
                {
                    "kind": kind.value,
                    "points": latest[trace.name].value,
                    "color": config.view_color_map.get(trace.name),
                }
            )
        payload: dict[str, Any] = {"series": series, **domains}
        artifact = Artifact(
            ArtifactKind.SVG,
            render_chart_svg(
                payload,
                color=config.view_color_map.get(owner),
                max_items=config.max_items_per_view,
            ),
            title=f"{owner}: overlay" if config.show_titles else None,
        )
        rendered.append(RenderedTraceFrame(event.step, artifact, dict(event.meta)))
    return rendered


def _overlay_domains(frames: Sequence[Frame]) -> dict[str, list[float]]:
    points = [
        point
        for frame in frames
        if is_numeric_point_sequence(frame.value)
        for point in frame.value
    ]
    if not points:
        return {"x_domain": [0.0, 1.0], "y_domain": [0.0, 1.0]}
    x_values = [float(point[0]) for point in points]
    y_values = [float(point[1]) for point in points]
    return {"x_domain": _expanded_domain(x_values), "y_domain": _expanded_domain(y_values)}


def _expanded_domain(values: list[float]) -> list[float]:
    low, high = min(values), max(values)
    padding = (high - low) * 0.1 or 1.0
    return [low - padding, high + padding]
