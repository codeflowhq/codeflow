"""Small graph structures for concise algorithm examples and graph views."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field, replace

__all__ = ["Edge", "Graph", "NodeId", "ScoredSearchNode", "SearchNode", "Tree"]

type NodeId = str
type EdgeLabel = str | int | float
type Neighbors = list[NodeId] | dict[NodeId, EdgeLabel]


@dataclass(frozen=True, slots=True)
class Edge:
    """A labelled connection between two graph nodes."""

    source: NodeId
    target: NodeId
    label: str = ""


@dataclass(frozen=True, slots=True)
class SearchNode:
    """A search state with a parent link for path reconstruction."""

    state: NodeId
    parent: SearchNode | None = field(default=None, repr=False, compare=False)
    node_id: NodeId | None = field(default=None, repr=False, compare=False)

    def child(self, state: NodeId) -> SearchNode:
        """Return an unweighted child node."""

        return SearchNode(state, parent=self)

    def with_node_id(self, node_id: NodeId) -> SearchNode:
        """Return this search occurrence associated with a rendered tree node."""

        return replace(self, node_id=node_id)

    def path(self) -> list[NodeId]:
        """Return states from the root node through this node."""

        states: list[NodeId] = []
        current: SearchNode | None = self
        while current is not None:
            states.append(current.state)
            current = current.parent
        return list(reversed(states))

    @property
    def depth(self) -> int:
        """Return the number of edges between this node and the root."""

        return 0 if self.parent is None else self.parent.depth + 1


@dataclass(frozen=True, slots=True)
class ScoredSearchNode(SearchNode):
    """A search node carrying path and heuristic costs."""

    g: float = 0
    h: float = 0
    f: float = field(init=False, compare=False)

    def __post_init__(self) -> None:
        object.__setattr__(self, "f", self.g + self.h)

    def extend(
        self, state: NodeId, edge_cost: float, h: float = 0
    ) -> ScoredSearchNode:
        """Return a scored child with an accumulated path cost."""

        return ScoredSearchNode(state, g=self.g + edge_cost, h=h, parent=self)


@dataclass(frozen=True)
class Graph:
    """An adjacency-list graph that can also be rendered directly."""

    adjacency: dict[NodeId, Neighbors]
    labels: dict[NodeId, object] = field(default_factory=dict)
    directed: bool = False
    current: NodeId | None = None

    def __getitem__(self, node: NodeId) -> Neighbors:
        return self.adjacency[node]

    def edges_from(self, node: NodeId) -> list[Edge]:
        """Return outgoing edges, preserving optional adjacency-map weights."""

        neighbors = self.adjacency[node]
        if isinstance(neighbors, Mapping):
            return [
                Edge(node, target, str(label)) for target, label in neighbors.items()
            ]
        return [Edge(node, target) for target in neighbors]

    def highlight(self, node: NodeId | None) -> Graph:
        """Return this graph with the node currently expanded by an algorithm."""

        return replace(self, current=node)


@dataclass(frozen=True)
class Tree:
    """A growing search tree with generated or caller-provided node identifiers."""

    root_label: object
    root_id: NodeId = "t0"
    nodes: dict[NodeId, object] = field(default_factory=dict, repr=False)
    annotations: dict[NodeId, str] = field(default_factory=dict, repr=False)
    edges: tuple[Edge, ...] = ()
    current: NodeId | None = None
    _next_id: int = field(default=1, repr=False)

    def __post_init__(self) -> None:
        if not self.nodes:
            object.__setattr__(self, "nodes", {self.root_id: self.root_label})

    def add(
        self,
        parent: NodeId,
        label: object,
        edge_label: str = "",
        *,
        node_id: NodeId | None = None,
        annotation: str = "",
    ) -> tuple[Tree, NodeId]:
        """Return a tree with an edge to a generated or stable child node.

        A caller-provided ``node_id`` represents a logical state and is reused
        when it already exists. Omitting it creates a distinct occurrence,
        which is appropriate when the same state may appear on multiple paths.
        """

        child = node_id if node_id is not None else f"t{self._next_id}"
        nodes = self.nodes if child in self.nodes else {**self.nodes, child: label}
        annotations = self.annotations
        if annotation and child not in annotations:
            annotations = {**annotations, child: annotation}
        edge = Edge(parent, child, edge_label)
        edges = self.edges if edge in self.edges else (*self.edges, edge)
        tree = replace(
            self,
            nodes=nodes,
            annotations=annotations,
            edges=edges,
            _next_id=self._next_id + (node_id is None),
        )
        return tree, child

    def with_label(self, node: NodeId, label: object) -> Tree:
        """Return this tree with a node label updated."""

        if node not in self.nodes:
            raise KeyError(f"Unknown tree node: {node}")
        return replace(self, nodes={**self.nodes, node: label})

    def with_annotation(self, node: NodeId, annotation: str) -> Tree:
        """Return this tree with auxiliary text displayed outside a node."""

        if node not in self.nodes:
            raise KeyError(f"Unknown tree node: {node}")
        annotations = {**self.annotations}
        if annotation:
            annotations[node] = annotation
        else:
            annotations.pop(node, None)
        return replace(self, annotations=annotations)

    def highlight(self, node: NodeId | None) -> Tree:
        """Return this tree with the node currently expanded by an algorithm."""

        return replace(self, current=node)
