from __future__ import annotations

from dataclasses import fields, is_dataclass
from typing import Any

from ..value_shapes import _is_matrix_value


def _is_scalar_like(value: Any) -> bool:
    return value is None or isinstance(value, (str, int, float, bool))


def _estimate_dataclass_width(value: Any, max_items: int, max_width: int) -> int:
    visible_fields = [item for item in fields(value) if item.repr][:max_items]
    widths = [
        max(
            54,
            estimate_visual_width(item.name, max_items, max_width=max_width),
            estimate_visual_width(
                getattr(value, item.name), max_items, max_width=max_width
            ),
        )
        for item in visible_fields
    ]
    return min(max_width, max(72, sum(widths)))


def _estimate_matrix_width(value: Any, max_items: int, max_width: int) -> int:
    visible_rows = [list(row)[:max_items] for row in list(value)[:max_items]]
    row_widths = [
        sum(
            estimate_visual_width(item, max_items, max_width=max_width)
            for item in row
        )
        for row in visible_rows
    ]
    return min(max_width, max(row_widths, default=64))


def _estimate_structured_width(
    value: Any, max_items: int, max_width: int
) -> int | None:
    if is_dataclass(value) and not isinstance(value, type):
        return _estimate_dataclass_width(value, max_items, max_width)
    if _is_matrix_value(value):
        return _estimate_matrix_width(value, max_items, max_width)
    return None


def estimate_visual_width(
    value: Any, max_items: int = 6, *, max_width: int = 920
) -> int:
    """Estimate Graphviz HTML label width so sibling rows can share one width."""
    if _is_scalar_like(value):
        text = str(value)
        return min(max_width, max(54, 24 + len(text) * 9))

    if isinstance(value, dict):
        from .table_sizes import estimate_table_column_widths

        key_width, value_width = estimate_table_column_widths(
            list(value.items())[:max_items], max_items
        )
        return min(max_width, key_width + value_width + 56)

    structured_width = _estimate_structured_width(value, max_items, max_width)
    if structured_width is not None:
        return structured_width

    if isinstance(value, (list, tuple)):
        visible = list(value)[:max_items]
        if not visible:
            return 64
        width = sum(
            estimate_visual_width(item, max_items, max_width=max_width)
            for item in visible
        )
        width += max(0, len(visible) - 1) * 18 + 24
        if len(value) > len(visible):
            width += 42
        return min(max_width, max(64, width))

    if isinstance(value, (set, frozenset)):
        visible = sorted(value, key=lambda item: str(item))[:max_items]
        if not visible:
            return 64
        width = sum(
            estimate_visual_width(item, max_items, max_width=max_width)
            for item in visible
        )
        width += max(0, len(visible) - 1) * 18 + 24
        if len(value) > len(visible):
            width += 42
        return min(max_width, max(64, width))

    return max(72, min(max_width, 24 + len(type(value).__name__) * 9))


def estimate_visual_height(
    value: Any, max_items: int = 6, *, max_height: int = 420
) -> int:
    """Estimate Graphviz HTML label height for equal-sized sibling cells."""
    if _is_scalar_like(value):
        return 30

    if isinstance(value, dict):
        visible = list(value.items())[:max_items]
        row_count = max(1, len(visible))
        nested_extra = max(
            (
                estimate_visual_height(item, max_items, max_height=max_height) - 30
                for _, item in visible
            ),
            default=0,
        )
        return min(max_height, 34 + row_count * 28 + nested_extra)

    if is_dataclass(value) and not isinstance(value, type):
        visible_fields = [item for item in fields(value) if item.repr][:max_items]
        nested_extra = max(
            (
                estimate_visual_height(
                    getattr(value, item.name), max_items, max_height=max_height
                )
                - 30
                for item in visible_fields
            ),
            default=0,
        )
        return min(max_height, 64 + nested_extra)

    if isinstance(value, (list, tuple, set, frozenset)):
        visible = (
            list(value)[:max_items]
            if not isinstance(value, (set, frozenset))
            else sorted(value, key=lambda item: str(item))[:max_items]
        )
        if not visible:
            return 34
        child_height = max(
            estimate_visual_height(item, max_items, max_height=max_height)
            for item in visible
        )
        return min(max_height, child_height + 34)

    return 34
