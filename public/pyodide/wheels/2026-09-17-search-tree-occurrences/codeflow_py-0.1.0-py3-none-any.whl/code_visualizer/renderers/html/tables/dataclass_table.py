from __future__ import annotations

from collections.abc import Callable
from dataclasses import fields, is_dataclass
from typing import Any

from ...shared.theme import BG_HEADER_MUTED, BG_SURFACE
from ..labels import html_bold_text, html_cell, html_row, html_table

FormatNestedValue = Callable[[Any, int, int, Any, str], str]


def dataclass_html(
    value: Any,
    next_depth: int,
    max_items: int,
    nested_renderer: Any,
    slot_name: str,
    format_nested_value: FormatNestedValue,
) -> str | None:
    if not is_dataclass(value) or isinstance(value, type):
        return None

    visible_fields = [item for item in fields(value) if item.repr][:max_items]
    if not visible_fields:
        return None

    if len(visible_fields) == 1:
        field_info = visible_fields[0]
        return format_nested_value(
            getattr(value, field_info.name),
            next_depth,
            max_items,
            nested_renderer,
            f"{slot_name}.{field_info.name}",
        )

    headers = [
        html_cell(
            html_bold_text(item.name),
            align="center",
            bgcolor=BG_HEADER_MUTED,
            cellpadding="4",
        )
        for item in visible_fields
    ]
    values = [
        html_cell(
            format_nested_value(
                getattr(value, item.name),
                next_depth,
                max_items,
                nested_renderer,
                f"{slot_name}.{item.name}",
            ),
            align="center",
            bgcolor=BG_SURFACE,
            cellpadding="4",
        )
        for item in visible_fields
    ]
    return html_table(
        html_row(*headers),
        html_row(*values),
        border="1",
        cellborder="1",
        cellspacing="0",
        cellpadding="0",
    )
