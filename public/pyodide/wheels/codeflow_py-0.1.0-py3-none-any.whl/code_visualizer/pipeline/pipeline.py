from __future__ import annotations

from typing import Any, Literal

from ..shared.config import VisualizerConfig, default_visualizer_config
from ..shared.models import Artifact
from ..shared.view_kinds import ViewKind
from ..utils.value_shapes import _is_scalar_value
from .render_dispatch import (
    render_fallback_nodelink_artifact,
    render_scalar_artifact,
    render_structured_artifact,
)
from .resolver import determine_view, make_value_coercer, resolve_recursion_depth

DirectionLiteral = Literal["LR", "TD"]
render_structured_view = render_structured_artifact


def _normalize_slot_name(name: str) -> str:
    normalized = str(name).strip()
    return normalized or "x"


def _resolve_direction_for_slot(
    cfg: VisualizerConfig,
    slot_name: str,
) -> DirectionLiteral:
    slot_direction = cfg.view_graph_direction_map.get(slot_name, cfg.graph_direction)
    return "TD" if slot_direction == "TB" else "LR"


def visualize(
    value: Any, *, name: str = "x", config: VisualizerConfig | None = None
) -> Artifact:
    cfg = (
        config.copy().normalized()
        if config is not None
        else default_visualizer_config().normalized()
    )
    slot_name = _normalize_slot_name(name)
    resolved_direction = _resolve_direction_for_slot(cfg, slot_name)
    value_coercer = make_value_coercer(cfg)

    original_value = value
    coerced_value = value_coercer(value)

    def resolver(slot: str, raw: Any, coerced: Any) -> tuple[ViewKind, bool]:
        return determine_view(slot, raw, coerced, cfg)

    view, configured_view = determine_view(
        slot_name, original_value, coerced_value, cfg
    )
    recursion_budget = resolve_recursion_depth(slot_name, original_value, cfg)
    focus_path = cfg.focus_path_map.get(slot_name)
    accent_color = cfg.view_color_map.get(slot_name)
    show_indices = cfg.view_show_indices_map.get(slot_name, False)

    artifact, handled = render_structured_view(
        view=view,
        name=slot_name,
        value=coerced_value,
        direction=resolved_direction,
        recursion_budget=recursion_budget,
        item_limit=cfg.max_items_per_view,
        configured_view=configured_view,
        value_coercer=value_coercer,
        view_resolver=resolver,
        focus_path=focus_path,
        accent_color=accent_color,
        show_titles=cfg.show_titles,
        show_indices=show_indices,
    )
    if artifact is not None:
        return artifact
    if handled:
        view = ViewKind.NODE_LINK

    if _is_scalar_value(coerced_value):
        return render_scalar_artifact(
            slot_name,
            coerced_value,
            resolved_direction,
            show_titles=cfg.show_titles,
        )

    return render_fallback_nodelink_artifact(
        value=coerced_value,
        name=slot_name,
        direction=resolved_direction,
        max_depth=cfg.max_depth,
        max_items=cfg.max_items_per_view,
        value_coercer=value_coercer,
        show_titles=cfg.show_titles,
    )
