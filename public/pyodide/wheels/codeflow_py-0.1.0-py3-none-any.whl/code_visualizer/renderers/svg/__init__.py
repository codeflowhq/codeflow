"""Native SVG renderers for views that require fixed geometry."""
