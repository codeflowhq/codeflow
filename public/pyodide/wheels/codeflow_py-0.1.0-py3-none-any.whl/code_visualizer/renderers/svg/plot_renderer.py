from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from ..shared.theme import FILL_BAR_POSITIVE, normalize_hex_color

_WIDTH = 560
_HEIGHT = 340
_LEFT = 58
_RIGHT = 24
_TOP = 22
_BOTTOM = 48


@dataclass(frozen=True)
class _Series:
    points: list[tuple[float, float]]
    kind: str
    color: str | None


def render_plot_svg(value: Any, *, color: str | None, max_items: int) -> str:
    """Render a numeric sequence or generic chart payload as fixed-coordinate SVG."""

    accent = normalize_hex_color(color) or FILL_BAR_POSITIVE
    chart_data = _chart_data(value)
    if chart_data is not None:
        series, x_domain, y_domain = chart_data
        return _render_chart(series, x_domain, y_domain, accent)

    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        raise TypeError("line view expects list[number] or chart data")
    values = list(value)[:max_items]
    if any(not _is_number(item) for item in values):
        raise TypeError("line view expects list[number]")
    return _render_numeric_series([float(item) for item in values], accent)


def _render_chart(
    series: list[_Series],
    x_domain: tuple[float, float],
    y_domain: tuple[float, float],
    accent: str,
) -> str:
    chart = _Chart(x_domain, y_domain)
    content = [chart.axes()]
    clip_id = "line-plot"
    content.append(f'<clipPath id="{clip_id}"><rect x="{_LEFT}" y="{_TOP}" width="{chart.width}" height="{chart.height}" /></clipPath>')
    for series_index, item in enumerate(series):
        series_color = normalize_hex_color(item.color) or (accent if item.kind == "line" else "#475569")
        if item.kind == "line":
            coordinates = " ".join(f"{chart.x(x)},{chart.y(y)}" for x, y in item.points)
            content.append(
                f'<g data-anim-key="series-{series_index}" clip-path="url(#{clip_id})">'
                f'<polyline points="{coordinates}" fill="none" stroke="{series_color}" '
                'stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />'
                "</g>"
            )
        else:
            for point_index, (x, y) in enumerate(item.points):
                content.append(
                    f'<g data-anim-key="series-{series_index}-point-{point_index}" clip-path="url(#{clip_id})">'
                    f'<circle cx="{chart.x(x)}" cy="{chart.y(y)}" r="5.5" fill="{series_color}" />'
                    "</g>"
                )
    return _svg("".join(content))


def _render_numeric_series(values: list[float], accent: str) -> str:
    if not values:
        return _svg('<text x="280" y="170" text-anchor="middle" fill="#64748b">No values</text>')
    x_domain = (0.0, float(max(len(values) - 1, 1)))
    low, high = _padded_domain(min(values), max(values))
    points = [(float(index), value) for index, value in enumerate(values)]
    return _render_chart([_Series(points, "line", accent)], x_domain, (low, high), accent)


class _Chart:
    def __init__(self, x_domain: tuple[float, float], y_domain: tuple[float, float]) -> None:
        self.min_x, self.max_x = x_domain
        self.min_y, self.max_y = y_domain
        self.width = _WIDTH - _LEFT - _RIGHT
        self.height = _HEIGHT - _TOP - _BOTTOM

    def x(self, value: float) -> str:
        return _number(_LEFT + (value - self.min_x) / (self.max_x - self.min_x) * self.width)

    def y(self, value: float) -> str:
        return _number(_TOP + (self.max_y - value) / (self.max_y - self.min_y) * self.height)

    def axes(self) -> str:
        baseline = _TOP + self.height
        parts = [
            '<g data-anim-key="axes" stroke="#94a3b8" stroke-width="1.5" fill="none">',
            f'<line x1="{_LEFT}" y1="{baseline}" x2="{_LEFT + self.width}" y2="{baseline}" />',
            f'<line x1="{_LEFT}" y1="{baseline}" x2="{_LEFT}" y2="{_TOP}" />',
            "</g>",
            '<g data-anim-key="axis-labels" fill="#475569" font-family="sans-serif" font-size="12">',
        ]
        for value in _ticks(self.min_x, self.max_x):
            x = self.x(value)
            parts.append(f'<line x1="{x}" y1="{baseline}" x2="{x}" y2="{baseline + 5}" stroke="#94a3b8" />')
            parts.append(f'<text x="{x}" y="{baseline + 21}" text-anchor="middle">{_format(value)}</text>')
        for value in _ticks(self.min_y, self.max_y):
            y = self.y(value)
            parts.append(f'<line x1="{_LEFT - 5}" y1="{y}" x2="{_LEFT}" y2="{y}" stroke="#94a3b8" />')
            parts.append(f'<text x="{_LEFT - 10}" y="{_number(float(y) + 4)}" text-anchor="end">{_format(value)}</text>')
        parts.append(f'<text x="{_LEFT + self.width}" y="{baseline + 38}" text-anchor="end" font-size="15">x</text>')
        parts.append(f'<text x="{_LEFT - 18}" y="{_TOP + 4}" text-anchor="end" font-size="15">y</text>')
        parts.append("</g>")
        return "".join(parts)


def _chart_data(value: Any) -> tuple[list[_Series], tuple[float, float], tuple[float, float]] | None:
    if not isinstance(value, Mapping):
        return None
    raw_series = value.get("series")
    if not isinstance(raw_series, Sequence) or isinstance(raw_series, (str, bytes)):
        raise TypeError("line chart expects a series list")
    series: list[_Series] = []
    all_points: list[tuple[float, float]] = []
    for item in raw_series:
        if not isinstance(item, Mapping):
            raise TypeError("line chart expects each series as a mapping")
        kind = item.get("kind", "line")
        points = _points(item.get("points"))
        if kind not in {"line", "scatter"}:
            raise TypeError("line chart expects series kind as line or scatter")
        series.append(_Series(points, kind, item.get("color") if isinstance(item.get("color"), str) else None))
        all_points.extend(points)
    if not all_points:
        return series, (0.0, 1.0), (0.0, 1.0)
    x_values = [x for x, _ in all_points]
    y_values = [y for _, y in all_points]
    return (
        series,
        _domain(value, "x_domain", _padded_domain(min(x_values), max(x_values))),
        _domain(value, "y_domain", _padded_domain(min(y_values), max(y_values))),
    )


def _points(value: Any) -> list[tuple[float, float]]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        raise TypeError("line chart expects points as [x, y] pairs")
    points: list[tuple[float, float]] = []
    for point in value:
        if not isinstance(point, Sequence) or len(point) != 2 or not _is_number(point[0]) or not _is_number(point[1]):
            raise TypeError("line chart expects points as [x, y] pairs")
        points.append((float(point[0]), float(point[1])))
    return points


def _domain(value: Mapping[str, Any], key: str, fallback: tuple[float, float]) -> tuple[float, float]:
    candidate = value.get(key)
    if candidate is None:
        return fallback
    if not isinstance(candidate, Sequence) or len(candidate) != 2 or not _is_number(candidate[0]) or not _is_number(candidate[1]):
        raise TypeError(f"line chart expects {key} as [min, max]")
    lower, upper = float(candidate[0]), float(candidate[1])
    if upper <= lower:
        raise TypeError(f"line chart expects {key} with min < max")
    return lower, upper


def _padded_domain(low: float, high: float) -> tuple[float, float]:
    span = high - low
    padding = span * 0.1 if span else max(abs(low) * 0.1, 1.0)
    return low - padding, high + padding


def _ticks(lower: float, upper: float) -> list[float]:
    return [lower + (upper - lower) * index / 4 for index in range(5)]


def _is_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def _format(value: float) -> str:
    return f"{value:.2f}".rstrip("0").rstrip(".")


def _number(value: float) -> str:
    return f"{value:.2f}".rstrip("0").rstrip(".")


def _svg(content: str) -> str:
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {_WIDTH} {_HEIGHT}" '
        f'width="{_WIDTH}" height="{_HEIGHT}" role="img" aria-label="Line chart">{content}</svg>'
    )
