"""Renderer-only shared helpers."""
