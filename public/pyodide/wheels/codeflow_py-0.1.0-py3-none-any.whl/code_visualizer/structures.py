"""Small graph structures for concise algorithm examples and graph views."""

from __future__ import annotations

from dataclasses import dataclass, field, replace

__all__ = ["Edge", "Graph", "NodeId", "Tree"]

type NodeId = str


@dataclass(frozen=True, slots=True)
class Edge:
    """A labelled connection between two graph nodes."""

    source: NodeId
    target: NodeId
    label: str = ""


@dataclass(frozen=True)
class Graph:
    """An adjacency-list graph that can also be rendered directly."""

    adjacency: dict[NodeId, list[NodeId]]
    labels: dict[NodeId, str] = field(default_factory=dict)
    directed: bool = False
    current: NodeId | None = None

    def __getitem__(self, node: NodeId) -> list[NodeId]:
        return self.adjacency[node]

    def highlight(self, node: NodeId | None) -> Graph:
        """Return this graph with the node currently expanded by an algorithm."""

        return replace(self, current=node)


@dataclass(frozen=True)
class Tree:
    """A growing tree with generated node identifiers for search traces."""

    root_label: str
    root_id: NodeId = "t0"
    nodes: dict[NodeId, str] = field(default_factory=dict, repr=False)
    edges: tuple[Edge, ...] = ()
    current: NodeId | None = None
    _next_id: int = field(default=1, repr=False)

    def __post_init__(self) -> None:
        if not self.nodes:
            object.__setattr__(self, "nodes", {self.root_id: self.root_label})

    def add(
        self, parent: NodeId, label: str, edge_label: str = ""
    ) -> tuple[Tree, NodeId]:
        """Return a new tree with one child and that child's identifier."""

        child = f"t{self._next_id}"
        nodes = {**self.nodes, child: label}
        tree = replace(
            self,
            nodes=nodes,
            edges=(*self.edges, Edge(parent, child, edge_label)),
            _next_id=self._next_id + 1,
        )
        return tree, child

    def highlight(self, node: NodeId | None) -> Tree:
        """Return this tree with the node currently expanded by an algorithm."""

        return replace(self, current=node)
