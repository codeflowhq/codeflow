"""Primary public API surface for code_visualizer."""

from .core import ViewKind, VisualizerConfig, default_visualizer_config
from .pipeline import visualize
from .tracing import (
    RenderedTraceFrame,
    StepTracerUnavailableError,
    TraceManifest,
    TraceManifestEntry,
    TraceManifestStep,
    TraceOutputMode,
    VariableTraceEvent,
    build_traces,
    trace_algorithm,
    visualize_algorithm,
    visualize_trace,
    visualize_traces,
)

__all__ = [
    "VisualizerConfig",
    "ViewKind",
    "RenderedTraceFrame",
    "StepTracerUnavailableError",
    "TraceManifest",
    "TraceManifestEntry",
    "TraceManifestStep",
    "TraceOutputMode",
    "VariableTraceEvent",
    "build_traces",
    "default_visualizer_config",
    "trace_algorithm",
    "visualize_algorithm",
    "visualize",
    "visualize_trace",
    "visualize_traces",
]
